# Data Dictionary

users(id, email, role)
products(id, name, price)
orders(id, user_id, product_id, quantity)
