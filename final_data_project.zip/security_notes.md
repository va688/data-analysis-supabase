# Security Notes
- RLS enabled
- Users see own data
- Admin full access
- Custom delete function
