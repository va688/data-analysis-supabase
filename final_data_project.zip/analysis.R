library(DBI)
library(RPostgres)
library(dplyr)
library(ggplot2)

con <- dbConnect(
  RPostgres::Postgres(),
  host = "your-host",
  port = 5432,
  dbname = "postgres",
  user = "postgres",
  password = "your-password",
  sslmode = "require"
)

orders <- dbGetQuery(con, "SELECT * FROM orders")
products <- dbGetQuery(con, "SELECT * FROM products")

df <- merge(orders, products, by.x="product_id", by.y="id")

summary <- df %>%
  group_by(name) %>%
  summarise(total_qty = sum(quantity))

print(summary)

ggplot(summary, aes(x=name, y=total_qty, fill=name)) +
  geom_bar(stat="identity") +
  theme_minimal()
