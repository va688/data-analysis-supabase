-- ONLINE STORE DATABASE

create table users (
    id uuid primary key default gen_random_uuid(),
    email text unique not null,
    role text default 'user'
);

create table products (
    id uuid primary key default gen_random_uuid(),
    name text,
    price numeric
);

create table orders (
    id uuid primary key default gen_random_uuid(),
    user_id uuid references users(id),
    product_id uuid references products(id),
    quantity int
);

insert into users (email, role) values
('admin@test.com','admin'),
('user1@test.com','user'),
('user2@test.com','user'),
('user3@test.com','user'),
('user4@test.com','user');

insert into products (name, price) values
('Laptop',800),
('Phone',500),
('Headphones',100),
('Keyboard',50),
('Mouse',30);

insert into orders (user_id, product_id, quantity)
select u.id, p.id, 1 from users u, products p limit 5;

alter table users enable row level security;
alter table products enable row level security;
alter table orders enable row level security;

create policy "Users view own orders"
on orders for select
using (auth.uid() = user_id);

create policy "Admins full access"
on orders for all
using (exists (
 select 1 from users where id = auth.uid() and role='admin'
));

create or replace function delete_order(order_id uuid)
returns void
language sql
security definer
as $$
 delete from orders where id = order_id;
$$;
