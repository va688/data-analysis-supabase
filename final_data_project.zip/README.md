# Data Analysis Project (Supabase + R)

## Overview
Online Store database analyzed using R.

## Tables
users, products, orders

## Features
- 3 tables + relationships
- RLS security
- Admin/User roles
- R analysis with ggplot2

## Setup
1. Run schema.sql in Supabase
2. Connect using analysis.R

## Author
Eric Odongo
